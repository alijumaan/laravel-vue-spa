import CKEditor from '@ckeditor/ckeditor5-vue';

export default CKEditor
