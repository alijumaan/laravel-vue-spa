<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="rtl">
<style>
    html {
        position: relative;
        min-height: 100%;
        padding-bottom:90px;
    }
</style>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-rtl.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
</head>
<body>

    <div id="app"></div>

    <script type="module" src="<?php echo e(mix('js/app.js')); ?>"></script>
    <script>

    </script>
</body>
</html>
<?php /**PATH /Users/ali/Desktop/Laravel/Vue-SPA/resources/views/vue.blade.php ENDPATH**/ ?>